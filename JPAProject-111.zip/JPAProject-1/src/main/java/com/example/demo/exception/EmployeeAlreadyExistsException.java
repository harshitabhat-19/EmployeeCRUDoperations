//This exception can be thrown when the user tries to add a customer that already exists in the database.
package com.example.demo.exception;

//provide implementation for exception class

public class EmployeeAlreadyExistsException extends RuntimeException {
	private String message;

    public EmployeeAlreadyExistsException() {} // constructor with default

    public EmployeeAlreadyExistsException(String msg) { // parameterized
        super(msg);
        this.message = msg;

}
}
