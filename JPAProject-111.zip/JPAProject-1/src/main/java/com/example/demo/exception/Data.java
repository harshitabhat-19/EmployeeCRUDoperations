package com.example.demo.exception;

public interface Data {

}
