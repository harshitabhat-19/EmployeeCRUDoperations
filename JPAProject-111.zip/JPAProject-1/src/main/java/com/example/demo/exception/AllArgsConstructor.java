package com.example.demo.exception;

public interface AllArgsConstructor {

}
