package com.example.demo.service;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.dao.Employee;
import com.example.demo.exception.EmployeeAlreadyExistsException;
import com.example.demo.exception.NoSuchEmployeeExistsException;

import com.example.demo.repo.EmployeeRepo;

@Service
public class EmpService {

    @Autowired
    EmployeeRepo er;

    // 🔹 GET ALL

    public List<Employee> findAllEmployee() {
        return er.findAll();
    }

    // 🔹 ADD
   
    public Employee addfunc(Employee employee) {
        Optional<Employee> existing = er.findById(employee.getId());

        if (existing.isEmpty()) {
            return er.save(employee);
        } else {
            throw new EmployeeAlreadyExistsException("Employee already exists");
        }
    }

    // 🔹 GET BY ID
   
    public Employee addId(int id) {
        return er.findById(id).orElse(null);
    }

    // 🔹 PUT - FULL UPDATE
    public Employee updateEmp(Integer id, Employee emp) {

        Employee existing = er.findById(id)
                .orElseThrow(() -> new NoSuchEmployeeExistsException("No such employee"));
        
        existing.setName(emp.getName());
        existing.setCity(emp.getCity());
        

        return er.save(existing);
    }

    // 🔹 PATCH - PARTIAL UPDATE
    public Employee partialUpdate(Integer id, Map<String, Object> updates) {

        Employee existing = er.findById(id)
                .orElseThrow(() -> new NoSuchEmployeeExistsException("No such employee"));

        if (updates.containsKey("name")) {
            existing.setName((String) updates.get("name"));
        }

        if (updates.containsKey("city")) {
            existing.setCity((String) updates.get("city"));
        }

       
        return er.save(existing);
    }
        

    // 🔹 DELETE
    public void deleteId(int id) {
        if (!er.existsById(id)) {
            throw new NoSuchEmployeeExistsException("No such employee");
        }
        er.deleteById(id);
    }
}