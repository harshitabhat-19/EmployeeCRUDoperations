package org.springframework.boot.web.error;

import com.example.demo.exception.AllArgsConstructor;
import com.example.demo.exception.Data;
import com.example.demo.exception.NoArgsConstructor;

@Data
@AllArgsConstructor
@org.springframework.boot.web.error.NoArgsConstructor

public class ErrorResponse {
	private int statusCode;
    private String message;

    public ErrorResponse(int statusCode,String message)
    {
        super();
        this.message = message;
    }
}

