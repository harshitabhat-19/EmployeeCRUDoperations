package org.springframework.boot.web.error;

public @interface NoArgsConstructor {

}
